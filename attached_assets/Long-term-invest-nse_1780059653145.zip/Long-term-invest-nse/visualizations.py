"""
Plotly Visualization Module.
Generates interactive charts for the dashboard.
"""

import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Dict, List

def plot_normalized_comparison(data: Dict, title: str = "Normalized Returns Comparison") -> go.Figure:
    """Plot normalized returns for multiple indices/stocks."""
    fig = go.Figure()

    colors = {"Nifty50": "#1f77b4", "Midcap150": "#ff7f0e"}

    for key in ["nifty_normalized", "midcap_normalized"]:
        if key in data and not data[key].empty:
            name = "Nifty 50" if "nifty" in key else "Nifty Midcap 150"
            fig.add_trace(go.Scatter(
                x=data[key].index,
                y=data[key].values,
                mode="lines",
                name=name,
                line=dict(color=colors.get(key.replace("_normalized", "").title(), "#333"), width=2),
                hovertemplate="%{x|%Y-%m-%d}<br>" + name + ": %{y:.2f}%<extra></extra>"
            ))

    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Normalized Return (%)",
        hovermode="x unified",
        template="plotly_white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        height=500
    )

    return fig

def plot_ratio(ratio_series: pd.Series, title: str = "Midcap 150 / Nifty 50 Ratio") -> go.Figure:
    """Plot ratio chart with reference line at 1.0."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=ratio_series.index,
        y=ratio_series.values,
        mode="lines",
        name="Ratio",
        line=dict(color="#9467bd", width=2),
        fill="tonexty",
        fillcolor="rgba(148, 103, 189, 0.1)"
    ))

    # Add horizontal reference lines
    fig.add_hline(y=1.0, line_dash="dash", line_color="gray", annotation_text="Parity")
    fig.add_hline(y=ratio_series.mean(), line_dash="dot", line_color="green", 
                  annotation_text=f"Mean: {ratio_series.mean():.2f}")

    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Ratio",
        hovermode="x unified",
        template="plotly_white",
        height=400
    )

    return fig

def plot_rolling_beta(beta_series: pd.Series) -> go.Figure:
    """Plot rolling beta chart."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=beta_series.index,
        y=beta_series.values,
        mode="lines",
        name="Rolling Beta (252d)",
        line=dict(color="#d62728", width=2)
    ))

    fig.add_hline(y=1.0, line_dash="dash", line_color="gray")
    fig.add_hline(y=0, line_dash="solid", line_color="black")

    fig.update_layout(
        title="Rolling Beta: Midcap 150 vs Nifty 50",
        xaxis_title="Date",
        yaxis_title="Beta",
        template="plotly_white",
        height=400
    )

    return fig

def plot_drawdown(prices: pd.Series, title: str = "Drawdown Analysis") -> go.Figure:
    """Plot underwater equity curve."""
    rolling_max = prices.cummax()
    drawdown = (prices - rolling_max) / rolling_max * 100

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=drawdown.index,
        y=drawdown.values,
        mode="lines",
        name="Drawdown %",
        line=dict(color="#e74c3c", width=1),
        fill="tozeroy",
        fillcolor="rgba(231, 76, 60, 0.2)"
    ))

    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Drawdown (%)",
        template="plotly_white",
        height=400
    )

    return fig

def plot_price_with_sma(prices: pd.Series, sma50: pd.Series, sma200: pd.Series,
                        title: str = "Price with Moving Averages") -> go.Figure:
    """Plot price with SMA 50 and SMA 200 overlays."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=prices.index, y=prices.values,
        mode="lines", name="Price",
        line=dict(color="#2c3e50", width=1.5)
    ))

    fig.add_trace(go.Scatter(
        x=sma50.index, y=sma50.values,
        mode="lines", name="SMA 50",
        line=dict(color="#3498db", width=1, dash="dash")
    ))

    fig.add_trace(go.Scatter(
        x=sma200.index, y=sma200.values,
        mode="lines", name="SMA 200",
        line=dict(color="#e67e22", width=1, dash="dash")
    ))

    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Price (INR)",
        template="plotly_white",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        height=500
    )

    return fig

def plot_score_breakdown(scorecard: Dict) -> go.Figure:
    """Plot radar/bar chart for 6-pillar score breakdown."""
    pillars = scorecard["pillars"]

    categories = ["Business\nQuality", "Valuation", "Growth\nRunway", 
                "Competitive\nMoat", "Management", "Entry Price"]
    scores = [
        pillars["pillar1"]["score"],
        pillars["pillar2"]["score"],
        pillars["pillar3"]["score"],
        pillars["pillar4"]["score"],
        pillars["pillar5"]["score"],
        pillars["pillar6"]["score"],
    ]
    max_scores = [30, 20, 20, 15, 10, 5]

    fig = go.Figure()

    # Actual scores
    fig.add_trace(go.Bar(
        name="Score",
        x=categories,
        y=scores,
        marker_color=["#2ecc71", "#3498db", "#9b59b6", "#f1c40f", "#e67e22", "#e74c3c"],
        text=[f"{s}/{m}" for s, m in zip(scores, max_scores)],
        textposition="outside"
    ))

    # Max scores reference
    fig.add_trace(go.Scatter(
        name="Maximum",
        x=categories,
        y=max_scores,
        mode="markers",
        marker=dict(symbol="line-ew", size=20, color="gray"),
    ))

    fig.update_layout(
        title=f"6-Pillar Score Breakdown: {scorecard['name']} ({scorecard['total_score']}/100)",
        yaxis_title="Points",
        template="plotly_white",
        showlegend=True,
        height=450,
        barmode="group"
    )

    return fig

def plot_portfolio_allocation(recommendations: List[Dict]) -> go.Figure:
    """Plot portfolio signal distribution."""
    signals = {}
    for r in recommendations:
        sig = r["signal"]
        signals[sig] = signals.get(sig, 0) + 1

    if not signals:
        fig = go.Figure()
        fig.update_layout(title="No portfolio data", template="plotly_white", height=400)
        return fig

    fig = px.pie(
        names=list(signals.keys()),
        values=list(signals.values()),
        title="Portfolio Signal Distribution",
        color=list(signals.keys()),
        color_discrete_map={
            "STRONG BUY": "#27ae60",
            "BUY": "#2ecc71",
            "WATCHLIST": "#f39c12",
            "AVOID": "#e74c3c",
            "ERROR": "#95a5a6"
        }
    )
    fig.update_traces(textposition="inside", textinfo="percent+label")
    fig.update_layout(height=400, template="plotly_white")
    return fig
