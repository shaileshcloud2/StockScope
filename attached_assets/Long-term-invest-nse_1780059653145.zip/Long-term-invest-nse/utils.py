"""
Utility module for Financial Analytics Application.
Contains constants, sector benchmarks, and helper functions.
"""

import os
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union
import pandas as pd
import numpy as np

# ==================== CONSTANTS ====================

# Risk-free rate for India (as per document)
RISK_FREE_RATE = 0.06

# Index tickers
NIFTY_50_TICKER = "^NSEI"
NIFTY_MIDCAP_150_TICKER = "NIFTYMIDCAP150.NS"

# Cache settings
CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_cache")
DB_PATH = os.path.join(CACHE_DIR, "financial_data.db")

# Ensure cache directory exists
os.makedirs(CACHE_DIR, exist_ok=True)

# Sector PE benchmarks from document (FY2025)
SECTOR_PE_BENCHMARKS = {
    "Banking": 18.0,
    "IT": 28.0,
    "FMCG": 48.0,
    "Auto": 22.0,
    "Defence": 45.0,
    "Pharma": 32.0,
    "Chemicals": 30.0,
    "Infra/Capex": 40.0,
    "Retail": 70.0,
    "NBFC": 18.0,
    "Financial Services": 18.0,
    "Consumer Durables": 35.0,
    "Healthcare": 32.0,
    "Real Estate": 25.0,
    "Oil & Gas": 12.0,
    "Metals": 10.0,
    "Telecom": 20.0,
    "Power": 15.0,
    "General": 25.0,  # Default fallback
}

# Sector mapping heuristic (ticker to sector - simplified)
SECTOR_KEYWORDS = {
    "Banking": ["bank", "finance", "nbfc", "housing finance", "financial services"],
    "IT": ["software", "it services", "technology", "consulting", "computer"],
    "FMCG": ["food", "consumer goods", "beverages", "tobacco", "personal care", "fmcg"],
    "Auto": ["automobile", "auto", "vehicles", "tyres", "ancillary", "motor"],
    "Defence": ["defence", "aerospace", "military", "shipyard", "defense"],
    "Pharma": ["pharmaceutical", "drugs", "medicine", "biotech", "healthcare"],
    "Chemicals": ["chemical", "fertilizers", "pesticides", "dyes", "specialty chemicals"],
    "Infra/Capex": ["infrastructure", "construction", "cement", "capital goods", "engineering"],
    "Retail": ["retail", "e-commerce", "mall", "store", "consumer services"],
    "Real Estate": ["real estate", "property", "housing", "reits"],
    "Oil & Gas": ["oil", "gas", "petroleum", "energy", "exploration"],
    "Metals": ["steel", "metal", "mining", "iron", "aluminium", "copper"],
    "Telecom": ["telecom", "communication", "broadband", "wireless"],
    "Power": ["power", "electricity", "renewable", "energy generation"],
}

# Signal thresholds from document
SIGNAL_THRESHOLDS = {
    "STRONG BUY": (85, 100),
    "BUY": (70, 84),
    "WATCHLIST": (55, 69),
    "AVOID": (0, 54),
}

# Position sizing recommendations
POSITION_SIZING = {
    "STRONG BUY": (6.0, 10.0),
    "BUY": (3.0, 5.0),
    "WATCHLIST": (0.0, 0.0),
    "AVOID": (0.0, 0.0),
}

# Timeframe mappings (approximate trading days)
TIMEFRAMES = {
    "1Y": 252,
    "3Y": 756,
    "5Y": 1260,
    "Max": None,
}

# ==================== HELPER FUNCTIONS ====================

def get_sector_from_info(info: Dict) -> str:
    """
    Determine sector from yfinance info dict using keyword matching.
    Returns 'General' if unable to determine.
    """
    sector = info.get("sector", "")
    industry = info.get("industry", "")
    combined = f"{sector} {industry}".lower()

    for sector_name, keywords in SECTOR_KEYWORDS.items():
        if any(kw in combined for kw in keywords):
            return sector_name
    return "General"

def get_sector_pe(sector: str) -> float:
    """Get benchmark PE for a sector."""
    return SECTOR_PE_BENCHMARKS.get(sector, SECTOR_PE_BENCHMARKS["General"])

def calculate_cagr(start_value: float, end_value: float, years: float) -> float:
    """Calculate Compound Annual Growth Rate."""
    if start_value <= 0 or years <= 0 or end_value <= 0:
        return 0.0
    return (end_value / start_value) ** (1 / years) - 1

def safe_divide(numerator, denominator, default: float = 0.0):
    """
    Safe division handling zero or NaN denominator.
    Works with both scalar values and pandas Series.
    """
    # Handle pandas Series
    if isinstance(denominator, pd.Series):
        result = numerator / denominator
        result = result.replace([np.inf, -np.inf], np.nan)
        result = result.fillna(default)
        return result

    # Handle scalar values
    if denominator == 0 or pd.isna(denominator):
        return default
    return numerator / denominator

def format_percent(value: float, decimals: int = 2) -> str:
    """Format float as percentage string."""
    if pd.isna(value):
        return "N/A"
    return f"{value * 100:.{decimals}f}%"

def format_number(value: float, decimals: int = 2) -> str:
    """Format float with commas."""
    if pd.isna(value):
        return "N/A"
    return f"{value:,.{decimals}f}"

def get_signal_from_score(score: float) -> str:
    """Determine investment signal from total score."""
    for signal, (low, high) in SIGNAL_THRESHOLDS.items():
        if low <= score <= high:
            return signal
    return "AVOID"

def get_position_size_recommendation(signal: str) -> str:
    """Get position sizing recommendation based on signal."""
    if signal in POSITION_SIZING:
        low, high = POSITION_SIZING[signal]
        if low == 0:
            return "Zero allocation"
        return f"{low}% - {high}% of portfolio"
    return "Zero allocation"

def years_between(start_date, end_date) -> float:
    """Calculate years between two dates."""
    return (end_date - start_date).days / 365.25

def ensure_ns_suffix(ticker: str) -> str:
    """Ensure NSE ticker has .NS suffix."""
    ticker = ticker.upper().strip()
    if not ticker.endswith(".NS") and not ticker.startswith("^"):
        ticker += ".NS"
    return ticker

def remove_ns_suffix(ticker: str) -> str:
    """Remove .NS suffix for display."""
    return ticker.replace(".NS", "")
