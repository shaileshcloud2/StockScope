"""
Financial Analytics Engine.
Calculates performance metrics, risk ratios, and technical indicators.
"""

import pandas as pd
import numpy as np
from typing import Dict, Optional, Tuple
from utils import RISK_FREE_RATE, calculate_cagr, safe_divide, years_between

def calculate_daily_returns(prices: pd.Series) -> pd.Series:
    """Calculate daily percentage returns."""
    return prices.pct_change().dropna()

def calculate_normalized_returns(prices: pd.Series) -> pd.Series:
    """
    Calculate normalized returns (base 100) for comparison.
    """
    if prices.empty or prices.iloc[0] == 0:
        return prices
    return (prices / prices.iloc[0] - 1) * 100

def calculate_cagr_from_prices(prices: pd.Series) -> float:
    """Calculate CAGR from price series."""
    if len(prices) < 2:
        return 0.0
    start_price = prices.iloc[0]
    end_price = prices.iloc[-1]
    yrs = years_between(prices.index[0], prices.index[-1])
    return calculate_cagr(start_price, end_price, yrs)

def calculate_volatility(returns: pd.Series, annualize: bool = True) -> float:
    """Calculate annualized volatility."""
    if returns.empty:
        return 0.0
    vol = returns.std()
    if annualize:
        vol *= np.sqrt(252)
    return vol

def calculate_sharpe_ratio(returns: pd.Series, risk_free: float = RISK_FREE_RATE) -> float:
    """
    Calculate Sharpe Ratio assuming 252 trading days.
    risk_free: Annual risk-free rate (e.g., 0.06 for 6%)
    """
    if returns.empty:
        return 0.0

    excess_returns = returns - (risk_free / 252)
    if excess_returns.std() == 0:
        return 0.0

    sharpe = excess_returns.mean() / excess_returns.std() * np.sqrt(252)
    return sharpe

def calculate_max_drawdown(prices: pd.Series) -> Tuple[float, pd.Series]:
    """
    Calculate maximum drawdown and drawdown series.
    Returns: (max_drawdown_pct, drawdown_series)
    """
    if prices.empty:
        return 0.0, prices

    rolling_max = prices.cummax()
    drawdown = (prices - rolling_max) / rolling_max
    max_dd = drawdown.min()
    return max_dd, drawdown

def calculate_rolling_beta(stock_returns: pd.Series, market_returns: pd.Series, 
                           window: int = 252) -> pd.Series:
    """
    Calculate rolling beta of stock relative to market.
    Beta = Cov(stock, market) / Var(market)
    """
    if stock_returns.empty or market_returns.empty:
        return pd.Series()

    # Align indices
    aligned = pd.concat([stock_returns, market_returns], axis=1).dropna()
    if len(aligned) < window:
        return pd.Series()

    stock_col, market_col = aligned.columns[0], aligned.columns[1]

    cov = aligned[stock_col].rolling(window=window, min_periods=window//2).cov(aligned[market_col])
    var = aligned[market_col].rolling(window=window, min_periods=window//2).var()

    beta = safe_divide(cov, var, default=0)
    return beta

def calculate_beta(stock_returns: pd.Series, market_returns: pd.Series) -> float:
    """Calculate overall beta for the entire period."""
    aligned = pd.concat([stock_returns, market_returns], axis=1).dropna()
    if len(aligned) < 30:
        return 0.0

    cov = aligned.iloc[:, 0].cov(aligned.iloc[:, 1])
    var = aligned.iloc[:, 1].var()
    return safe_divide(cov, var, default=0)

def calculate_sma(prices: pd.Series, window: int) -> pd.Series:
    """Calculate Simple Moving Average."""
    return prices.rolling(window=window, min_periods=1).mean()

def calculate_ratio(series1: pd.Series, series2: pd.Series) -> pd.Series:
    """Calculate ratio of two price series (aligned by date)."""
    aligned = pd.concat([series1, series2], axis=1).dropna()
    if aligned.empty:
        return pd.Series()
    return aligned.iloc[:, 0] / aligned.iloc[:, 1]

def calculate_performance_metrics(prices: pd.Series, 
                                  risk_free: float = RISK_FREE_RATE) -> Dict:
    """
    Comprehensive performance metrics for a price series.
    """
    if prices.empty or len(prices) < 2:
        return {
            "CAGR": 0.0, "Volatility (Ann.)": 0.0, "Sharpe Ratio": 0.0,
            "Max Drawdown": 0.0, "Calmar Ratio": 0.0, "Total Return": 0.0,
            "Start Price": 0.0, "End Price": 0.0,
        }

    returns = calculate_daily_returns(prices)

    cagr = calculate_cagr_from_prices(prices)
    volatility = calculate_volatility(returns)
    sharpe = calculate_sharpe_ratio(returns, risk_free)
    max_dd, _ = calculate_max_drawdown(prices)

    # Calmar ratio: CAGR / Max Drawdown
    calmar = safe_divide(cagr, abs(max_dd), default=0) if max_dd != 0 else 0

    return {
        "CAGR": cagr,
        "Volatility (Ann.)": volatility,
        "Sharpe Ratio": sharpe,
        "Max Drawdown": max_dd,
        "Calmar Ratio": calmar,
        "Total Return": (prices.iloc[-1] / prices.iloc[0] - 1),
        "Start Price": prices.iloc[0],
        "End Price": prices.iloc[-1],
    }

def calculate_index_comparison(nifty_prices: pd.Series, midcap_prices: pd.Series,
                               window: int = 252) -> Dict:
    """
    Calculate comparison metrics between Nifty 50 and Midcap 150.
    """
    # Align dates
    aligned = pd.concat([nifty_prices, midcap_prices], axis=1).dropna()
    aligned.columns = ["Nifty50", "Midcap150"]

    if aligned.empty:
        return {
            "nifty_normalized": pd.Series(),
            "midcap_normalized": pd.Series(),
            "ratio": pd.Series(),
            "rolling_beta": pd.Series(),
            "nifty_metrics": {},
            "midcap_metrics": {},
        }

    nifty_ret = calculate_daily_returns(aligned["Nifty50"])
    midcap_ret = calculate_daily_returns(aligned["Midcap150"])

    # Rolling beta of Midcap relative to Nifty
    rolling_beta = calculate_rolling_beta(midcap_ret, nifty_ret, window)

    # Ratio series
    ratio = aligned["Midcap150"] / aligned["Nifty50"]

    # Normalized returns
    nifty_norm = calculate_normalized_returns(aligned["Nifty50"])
    midcap_norm = calculate_normalized_returns(aligned["Midcap150"])

    return {
        "nifty_normalized": nifty_norm,
        "midcap_normalized": midcap_norm,
        "ratio": ratio,
        "rolling_beta": rolling_beta,
        "nifty_metrics": calculate_performance_metrics(aligned["Nifty50"]),
        "midcap_metrics": calculate_performance_metrics(aligned["Midcap150"]),
    }

def filter_by_date(df: pd.DataFrame, start_date, end_date) -> pd.DataFrame:
    """Filter DataFrame by date range. Handles timezone-aware indices from yfinance."""
    if df.empty:
        return df

    # Convert index to timezone-naive to match Streamlit date_input (which is naive)
    idx = df.index
    if idx.tz is not None:
        idx = idx.tz_localize(None)

    # Convert inputs to pandas Timestamp (naive)
    start_ts = pd.Timestamp(start_date)
    end_ts = pd.Timestamp(end_date)

    mask = (idx >= start_ts) & (idx <= end_ts)
    return df.loc[mask]
