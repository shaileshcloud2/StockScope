"""
Portfolio Management Module.
Handles portfolio construction, position sizing, exit rules, and rebalancing.
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import pandas as pd
from utils import DB_PATH, get_signal_from_score, SIGNAL_THRESHOLDS, POSITION_SIZING
from scoring_engine import calculate_full_score

class PortfolioManager:
    """Manages long-term portfolio with scoring-based rules."""

    def __init__(self):
        self.db_path = DB_PATH
        self.init_tables()

    def init_tables(self):
        """Ensure portfolio tables exist."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS portfolio (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT UNIQUE,
                shares REAL,
                avg_cost REAL,
                added_date TEXT,
                target_allocation REAL,
                notes TEXT,
                last_score REAL,
                last_signal TEXT,
                last_reviewed TEXT,
                consecutive_low_scores INTEGER DEFAULT 0
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS score_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticker TEXT,
                score_date TEXT,
                total_score REAL,
                pillar1 REAL,
                pillar2 REAL,
                pillar3 REAL,
                pillar4 REAL,
                pillar5 REAL,
                pillar6 REAL,
                signal TEXT,
                red_flags TEXT
            )
        """)

        conn.commit()
        conn.close()

    def add_position(self, ticker: str, shares: float, avg_cost: float, 
                     notes: str = "") -> bool:
        """Add a new position to the portfolio."""
        ticker = ticker.upper().strip()
        if not ticker.endswith(".NS") and not ticker.startswith("^"):
            ticker += ".NS"

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        try:
            cursor.execute("""
                INSERT OR REPLACE INTO portfolio 
                (ticker, shares, avg_cost, added_date, notes, last_reviewed)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (ticker, shares, avg_cost, datetime.now().isoformat(), notes, 
                  datetime.now().isoformat()))
            conn.commit()
            return True
        except Exception as e:
            print(f"Error adding position: {e}")
            return False
        finally:
            conn.close()

    def remove_position(self, ticker: str) -> bool:
        """Remove a position from the portfolio."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM portfolio WHERE ticker = ?", (ticker,))
        conn.commit()
        conn.close()
        return True

    def get_portfolio(self) -> pd.DataFrame:
        """Get current portfolio as DataFrame."""
        conn = sqlite3.connect(self.db_path)
        df = pd.read_sql_query("SELECT * FROM portfolio", conn)
        conn.close()
        return df

    def record_score(self, ticker: str, scorecard: Dict):
        """Record score history for trend analysis."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        pillars = scorecard["pillars"]
        cursor.execute("""
            INSERT INTO score_history 
            (ticker, score_date, total_score, pillar1, pillar2, pillar3, pillar4, pillar5, pillar6, signal, red_flags)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            ticker,
            datetime.now().isoformat(),
            scorecard["total_score"],
            pillars["pillar1"]["score"],
            pillars["pillar2"]["score"],
            pillars["pillar3"]["score"],
            pillars["pillar4"]["score"],
            pillars["pillar5"]["score"],
            pillars["pillar6"]["score"],
            scorecard["signal"],
            json.dumps(scorecard["red_flags"])
        ))
        conn.commit()
        conn.close()

    def get_score_history(self, ticker: str) -> pd.DataFrame:
        """Get score history for a ticker."""
        conn = sqlite3.connect(self.db_path)
        df = pd.read_sql_query(
            "SELECT * FROM score_history WHERE ticker = ? ORDER BY score_date DESC",
            conn, params=(ticker,)
        )
        conn.close()
        return df

    def check_exit_rules(self, ticker: str, scorecard: Dict) -> List[str]:
        """
        Check all exit rules from the document.
        Returns list of exit triggers.
        """
        triggers = []
        history = self.get_score_history(ticker)

        # Rule 9: Score drops below 55 for 2 consecutive quarters
        if len(history) >= 2:
            last_two = history.head(2)
            if all(s < 55 for s in last_two["total_score"]):
                triggers.append("EXIT: Score < 55 for 2 consecutive reviews")

        # Rule 10: Promoter pledge > 20% OR holding < 25%
        # (Requires manual input, check overrides)

        # Rule 11: Revenue growth negative for 2 consecutive quarters
        # (Tracked via score history pillar1 decline)
        if len(history) >= 2:
            p1_drop = history.iloc[0]["pillar1"] - history.iloc[1]["pillar1"]
            if p1_drop > 8:
                triggers.append("EXIT: Business Quality dropped > 8 points in one review")

        # Rule 12: Auditor qualification (requires manual flag)

        # Rule 13: Moat broken - competitor takes > 5% share (manual)

        # Rule 14: Better opportunity (handled in rebalancing)

        # Rule 15: Target achieved + score drops below 70
        # (Requires tracking cost basis and current price)

        # Current red flags
        if scorecard["red_flags"]:
            for flag in scorecard["red_flags"]:
                if flag.startswith("CRITICAL"):
                    triggers.append(f"EXIT TRIGGER: {flag}")

        return triggers

    def get_rebalancing_recommendations(self) -> List[Dict]:
        """
        Analyze portfolio and return rebalancing recommendations.
        """
        portfolio = self.get_portfolio()
        recommendations = []

        if portfolio.empty:
            return recommendations

        for _, row in portfolio.iterrows():
            ticker = row["ticker"]
            try:
                scorecard = calculate_full_score(ticker)
                self.record_score(ticker, scorecard)

                signal = scorecard["signal"]
                score = scorecard["total_score"]
                red_flags = scorecard["red_flags"]
                exit_triggers = self.check_exit_rules(ticker, scorecard)

                # Determine action
                if exit_triggers:
                    action = "EXIT"
                    reason = "; ".join(exit_triggers)
                elif signal == "STRONG BUY":
                    action = "HOLD/ADD"
                    reason = f"Strong Buy ({score}/100). Consider increasing to 6-10% on dips."
                elif signal == "BUY":
                    action = "HOLD"
                    reason = f"Buy ({score}/100). Add on 10-15% corrections."
                elif signal == "WATCHLIST":
                    action = "REVIEW"
                    reason = f"Watchlist ({score}/100). Set price alert for better entry."
                else:
                    action = "EXIT"
                    reason = f"Avoid ({score}/100). Weak fundamentals or moat."

                recommendations.append({
                    "ticker": ticker,
                    "signal": signal,
                    "score": score,
                    "action": action,
                    "reason": reason,
                    "red_flags": red_flags,
                    "exit_triggers": exit_triggers,
                    "position_size": scorecard["position_size"],
                    "pillars": scorecard["pillars"],
                })

            except Exception as e:
                recommendations.append({
                    "ticker": ticker,
                    "signal": "ERROR",
                    "score": 0,
                    "action": "REVIEW",
                    "reason": f"Error in analysis: {str(e)}",
                    "red_flags": [],
                    "exit_triggers": [],
                    "position_size": "Unknown",
                    "pillars": {},
                })

        return recommendations

    def get_portfolio_summary(self) -> Dict:
        """Get high-level portfolio statistics."""
        portfolio = self.get_portfolio()
        if portfolio.empty:
            return {"positions": 0, "signals": {}}

        recs = self.get_rebalancing_recommendations()
        signals = {}
        for r in recs:
            sig = r["signal"]
            signals[sig] = signals.get(sig, 0) + 1

        return {
            "positions": len(portfolio),
            "signals": signals,
            "recommendations": recs,
        }
