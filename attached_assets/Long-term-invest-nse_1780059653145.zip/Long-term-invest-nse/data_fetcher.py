"""
Data Fetching and Caching Module.
Handles all yfinance interactions with SQLite local caching.
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple
import pandas as pd
import yfinance as yf
from utils import DB_PATH, ensure_ns_suffix, get_sector_from_info

def init_database():
    """Initialize SQLite database with required tables."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Index/Stock price data cache
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS price_data (
            ticker TEXT,
            date TEXT,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume REAL,
            dividends REAL,
            stock_splits REAL,
            fetched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (ticker, date)
        )
    """)

    # Stock fundamentals cache
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS fundamentals (
            ticker TEXT,
            metric TEXT,
            value TEXT,
            fetched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (ticker, metric)
        )
    """)

    # Portfolio holdings
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS portfolio (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT UNIQUE,
            shares REAL,
            avg_cost REAL,
            added_date TEXT,
            target_allocation REAL,
            notes TEXT,
            last_score REAL,
            last_signal TEXT,
            last_reviewed TEXT
        )
    """)

    # Score history for tracking changes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS score_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticker TEXT,
            score_date TEXT,
            total_score REAL,
            pillar1 REAL,
            pillar2 REAL,
            pillar3 REAL,
            pillar4 REAL,
            pillar5 REAL,
            pillar6 REAL,
            signal TEXT,
            red_flags TEXT
        )
    """)

    conn.commit()
    conn.close()

def is_cache_fresh(ticker: str, table: str, max_age_hours: int = 24) -> bool:
    """Check if cached data is still fresh."""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            f"SELECT MAX(fetched_at) FROM {table} WHERE ticker = ?",
            (ticker,)
        )
        result = cursor.fetchone()[0]
        conn.close()

        if result is None:
            return False

        last_fetch = datetime.strptime(result, "%Y-%m-%d %H:%M:%S")
        return datetime.now() - last_fetch < timedelta(hours=max_age_hours)
    except Exception:
        return False

def save_price_data(ticker: str, df: pd.DataFrame):
    """Save price DataFrame to SQLite."""
    if df.empty:
        return

    conn = sqlite3.connect(DB_PATH)
    df_copy = df.copy()
    df_copy["ticker"] = ticker
    df_copy.reset_index(inplace=True)

    # Rename columns to match schema
    col_map = {
        "Date": "date",
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
        "Volume": "volume",
        "Dividends": "dividends",
        "Stock Splits": "stock_splits"
    }
    df_copy.rename(columns={k: v for k, v in col_map.items() if k in df_copy.columns}, inplace=True)

    # Ensure required columns exist
    for col in ["open", "high", "low", "close", "volume"]:
        if col not in df_copy.columns:
            df_copy[col] = 0.0

    for col in ["dividends", "stock_splits"]:
        if col not in df_copy.columns:
            df_copy[col] = 0.0

    # Delete old data for this ticker
    cursor = conn.cursor()
    cursor.execute("DELETE FROM price_data WHERE ticker = ?", (ticker,))

    # Insert new data
    df_copy[["ticker", "date", "open", "high", "low", "close", "volume", "dividends", "stock_splits"]].to_sql(
        "price_data", conn, if_exists="append", index=False
    )
    conn.commit()
    conn.close()

def load_price_data(ticker: str) -> pd.DataFrame:
    """Load price data from SQLite cache. Capitalizes columns to match yfinance output."""
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(
        "SELECT * FROM price_data WHERE ticker = ? ORDER BY date",
        conn, params=(ticker,)
    )
    conn.close()

    if df.empty:
        return df

    df["date"] = pd.to_datetime(df["date"])
    df.set_index("date", inplace=True)

    # Capitalize column names to match yfinance output (Open, High, Low, Close, Volume)
    col_map = {
        "open": "Open", "high": "High", "low": "Low", "close": "Close",
        "volume": "Volume", "dividends": "Dividends", "stock_splits": "Stock Splits"
    }
    df.rename(columns={k: v for k, v in col_map.items() if k in df.columns}, inplace=True)

    # Recalculate Returns if Close exists
    if "Close" in df.columns:
        df["Returns"] = df["Close"].pct_change()

    return df

def save_fundamentals(ticker: str, info: Dict):
    """Save yfinance info dict to SQLite as key-value pairs."""
    if not info:
        return

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM fundamentals WHERE ticker = ?", (ticker,))

    for key, value in info.items():
        # Convert non-primitive types to string
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        else:
            value = str(value)
        cursor.execute(
            "INSERT OR REPLACE INTO fundamentals (ticker, metric, value) VALUES (?, ?, ?)",
            (ticker, key, value)
        )

    conn.commit()
    conn.close()

def load_fundamentals(ticker: str) -> Dict:
    """Load fundamentals from SQLite cache."""
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(
        "SELECT metric, value FROM fundamentals WHERE ticker = ?",
        conn, params=(ticker,)
    )
    conn.close()

    if df.empty:
        return {}

    return dict(zip(df["metric"], df["value"]))

def fetch_price_data(ticker: str, period: str = "5y", interval: str = "1d", 
                     force_refresh: bool = False) -> pd.DataFrame:
    """
    Fetch historical price data from yfinance with caching.

    Args:
        ticker: Yahoo Finance ticker symbol
        period: Data period (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        interval: Data interval (1d, 1wk, 1mo)
        force_refresh: Bypass cache and fetch fresh data

    Returns:
        DataFrame with OHLCV data
    """
    ticker = ensure_ns_suffix(ticker)

    # Check cache first
    if not force_refresh and is_cache_fresh(ticker, "price_data", max_age_hours=24):
        df = load_price_data(ticker)
        if not df.empty:
            return df

    try:
        stock = yf.Ticker(ticker)
        df = stock.history(period=period, interval=interval)

        if df.empty:
            raise ValueError(f"No data returned for {ticker}")

        # Calculate daily returns
        df["Returns"] = df["Close"].pct_change()

        save_price_data(ticker, df)
        return df

    except Exception as e:
        # Try loading stale cache as fallback
        df = load_price_data(ticker)
        if not df.empty:
            return df
        raise ConnectionError(f"Failed to fetch data for {ticker}: {str(e)}")

def fetch_stock_info(ticker: str, force_refresh: bool = False) -> Dict:
    """
    Fetch comprehensive stock info from yfinance with caching.
    Returns dictionary with fundamental data.
    """
    ticker = ensure_ns_suffix(ticker)

    if not force_refresh:
        cached = load_fundamentals(ticker)
        if cached and is_cache_fresh(ticker, "fundamentals", max_age_hours=24):
            return cached

    try:
        stock = yf.Ticker(ticker)
        info = stock.info

        # Enhance with additional data
        info["_ticker"] = ticker
        info["_sector"] = get_sector_from_info(info)
        info["_fetched_at"] = datetime.now().isoformat()

        save_fundamentals(ticker, info)
        return info

    except Exception as e:
        cached = load_fundamentals(ticker)
        if cached:
            return cached
        raise ConnectionError(f"Failed to fetch info for {ticker}: {str(e)}")

def fetch_financial_statements(ticker: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Fetch financial statements for scoring calculations.
    Returns: (income_stmt, balance_sheet, cash_flow)
    """
    ticker = ensure_ns_suffix(ticker)

    try:
        stock = yf.Ticker(ticker)
        income = stock.financials
        balance = stock.balance_sheet
        cashflow = stock.cashflow
        return income, balance, cashflow
    except Exception as e:
        # Return empty DataFrames on failure
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

# Initialize DB on module import
init_database()
