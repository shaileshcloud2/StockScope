"""
6-Pillar Long-Term Investment Scoring Engine.
Implements the complete scoring framework from the investment philosophy document.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from utils import (
    get_sector_from_info, get_sector_pe, safe_divide, calculate_cagr,
    ensure_ns_suffix, get_signal_from_score, get_position_size_recommendation
)
from data_fetcher import fetch_stock_info, fetch_financial_statements, fetch_price_data

# ==================== PILLAR 1: BUSINESS QUALITY (30 pts) ====================

def score_revenue_growth(revenue_cagr: float) -> int:
    """Sub-factor 1A: Revenue Growth 3-Year CAGR (+8 pts)"""
    if revenue_cagr >= 0.25: return 8
    elif revenue_cagr >= 0.20: return 7
    elif revenue_cagr >= 0.15: return 6
    elif revenue_cagr >= 0.10: return 4
    elif revenue_cagr >= 0.05: return 2
    elif revenue_cagr >= 0: return 1
    else: return 0

def score_pat_growth(pat_cagr: float) -> int:
    """Sub-factor 1B: PAT Growth 3-Year CAGR (+7 pts)"""
    if pat_cagr >= 0.30: return 7
    elif pat_cagr >= 0.20: return 6
    elif pat_cagr >= 0.15: return 5
    elif pat_cagr >= 0.10: return 3
    elif pat_cagr >= 0: return 1
    else: return 0

def score_roe(roe_avg: float) -> int:
    """Sub-factor 1C: Return on Equity 3-year average (+7 pts)"""
    if roe_avg >= 0.25: return 7
    elif roe_avg >= 0.20: return 6
    elif roe_avg >= 0.15: return 5
    elif roe_avg >= 0.10: return 3
    elif roe_avg >= 0.05: return 1
    else: return 0

def score_roce(roce_avg: float) -> int:
    """Sub-factor 1D: Return on Capital Employed 3-year average (+5 pts)"""
    if roce_avg >= 0.25: return 5
    elif roce_avg >= 0.20: return 4
    elif roce_avg >= 0.15: return 3
    elif roce_avg >= 0.10: return 2
    else: return 0

def score_debt_equity(de_ratio: float, is_financial: bool = False,
                      npa_ratio: float = 0, car_ratio: float = 0) -> int:
    """
    Sub-factor 1E: Debt / Equity Ratio (+3 pts)
    For Financial Services: substitute with NPA and CAR
    """
    if is_financial:
        both_good = (npa_ratio < 0.02) and (car_ratio > 0.15)
        one_good = (npa_ratio < 0.02) or (car_ratio > 0.15)
        if both_good: 
            return 3
        elif one_good: 
            return 2
        elif npa_ratio < 0.05: 
            return 1
        else: 
            return 0
    else:
        if de_ratio <= 0.3: 
            return 3
        elif de_ratio <= 0.8: 
            return 2
        elif de_ratio <= 1.5: 
            return 1
        else: 
            return 0

def calculate_pillar1(info: Dict, income_stmt: pd.DataFrame, 
                      balance_sheet: pd.DataFrame, user_overrides: Dict = None) -> Dict:
    """
    Calculate Business Quality score (max 30).
    Uses financial statements for CAGR calculations when available.
    Falls back to info dict fields when statements are unavailable.
    """
    user_overrides = user_overrides or {}

    # Try to extract revenue and PAT from financial statements
    revenue_cagr = 0.0
    pat_cagr = 0.0

    try:
        if not income_stmt.empty and len(income_stmt.columns) >= 3:
            # yfinance financials: columns are dates (most recent first), rows are line items
            # Revenue is typically 'Total Revenue' or 'Revenue'
            rev_row = None
            for key in ["Total Revenue", "Revenue", "TotalRevenue", "Total Operating Revenue"]:
                if key in income_stmt.index:
                    rev_row = income_stmt.loc[key]
                    break

            pat_row = None
            for key in ["Net Income", "NetIncome", "Profit After Tax", "PAT", 
                        "Net Income From Continuing Operations", "Net Income applicable to common shares"]:
                if key in income_stmt.index:
                    pat_row = income_stmt.loc[key]
                    break

            if rev_row is not None and len(rev_row.dropna()) >= 2:
                vals = rev_row.dropna().values[:4]  # Last 4 years (including current)
                if len(vals) >= 2 and vals[-1] > 0:
                    # Calculate 3-year CAGR: from oldest to newest of the 3-year window
                    # income_stmt columns are descending (newest first), so vals[0] is latest
                    if len(vals) >= 4 and vals[3] > 0:
                        revenue_cagr = calculate_cagr(vals[3], vals[0], 3)
                    elif len(vals) == 3 and vals[2] > 0:
                        revenue_cagr = calculate_cagr(vals[2], vals[0], 2)

            if pat_row is not None and len(pat_row.dropna()) >= 2:
                vals = pat_row.dropna().values[:4]
                if len(vals) >= 4 and vals[3] > 0:
                    pat_cagr = calculate_cagr(vals[3], vals[0], 3)
                elif len(vals) == 3 and vals[2] > 0:
                    pat_cagr = calculate_cagr(vals[2], vals[0], 2)
    except Exception:
        pass

    # Fallback to info dict
    if revenue_cagr == 0 and "revenueGrowth" in info:
        try:
            revenue_cagr = float(info.get("revenueGrowth", 0))
        except (ValueError, TypeError):
            revenue_cagr = 0.0
    if pat_cagr == 0 and "earningsGrowth" in info:
        try:
            pat_cagr = float(info.get("earningsGrowth", 0))
        except (ValueError, TypeError):
            pat_cagr = 0.0

    # ROE and ROCE from info
    try:
        roe = float(info.get("returnOnEquity", 0) or 0)
        if roe > 1:  # Sometimes yfinance returns percentage as 0.20, sometimes 20
            roe = roe / 100
    except (ValueError, TypeError):
        roe = 0.0

    try:
        roce = float(info.get("returnOnCapitalEmployed", 0) or 0)
        if roce > 1:
            roce = roce / 100
    except (ValueError, TypeError):
        roce = 0.0

    # Debt/Equity
    try:
        de_ratio = float(info.get("debtToEquity", 0) or 0)
        if de_ratio > 10:  # yfinance sometimes returns as percentage (e.g., 45.23 meaning 0.4523)
            de_ratio = de_ratio / 100
    except (ValueError, TypeError):
        de_ratio = 0.0

    # Check if financial sector
    sector = info.get("_sector", "General")
    is_financial = sector in ["Banking", "Financial Services", "NBFC", "Insurance"]

    # NPA and CAR (for financials) - not easily available in yfinance, use defaults
    npa_ratio = 0.03  # Assume moderate if unknown
    car_ratio = 0.16  # Assume adequate if unknown

    # Apply user overrides
    revenue_cagr = user_overrides.get("revenue_cagr", revenue_cagr)
    pat_cagr = user_overrides.get("pat_cagr", pat_cagr)
    roe = user_overrides.get("roe", roe)
    roce = user_overrides.get("roce", roce)
    de_ratio = user_overrides.get("de_ratio", de_ratio)

    # Calculate scores
    rev_score = score_revenue_growth(revenue_cagr)
    pat_score = score_pat_growth(pat_cagr)
    roe_score = score_roe(roe)
    roce_score = score_roce(roce)
    de_score = score_debt_equity(de_ratio, is_financial, npa_ratio, car_ratio)

    total = rev_score + pat_score + roe_score + roce_score + de_score

    return {
        "score": min(30, total),
        "max": 30,
        "revenue_cagr": revenue_cagr,
        "pat_cagr": pat_cagr,
        "roe": roe,
        "roce": roce,
        "de_ratio": de_ratio,
        "details": {
            "Revenue Growth (3Y CAGR)": {"value": f"{revenue_cagr:.1%}", "points": rev_score, "max": 8},
            "PAT Growth (3Y CAGR)": {"value": f"{pat_cagr:.1%}", "points": pat_score, "max": 7},
            "ROE (3Y Avg)": {"value": f"{roe:.1%}", "points": roe_score, "max": 7},
            "ROCE (3Y Avg)": {"value": f"{roce:.1%}", "points": roce_score, "max": 5},
            "Debt/Equity": {"value": f"{de_ratio:.2f}", "points": de_score, "max": 3},
        }
    }

# ==================== PILLAR 2: VALUATION (20 pts) ====================

def score_peg(peg: float) -> int:
    """Sub-factor 2A: PEG Ratio (+8 pts)"""
    if peg < 0.75: return 8
    elif peg <= 1.0: return 7
    elif peg <= 1.5: return 5
    elif peg <= 2.0: return 3
    elif peg <= 3.0: return 1
    else: return 0

def score_pe_vs_sector(stock_pe: float, sector_pe: float) -> int:
    """Sub-factor 2B: PE vs Sector Median (+6 pts)"""
    if sector_pe <= 0:
        return 3  # Neutral if unknown
    ratio = stock_pe / sector_pe
    if ratio <= 0.7: return 6
    elif ratio <= 0.9: return 5
    elif ratio <= 1.1: return 4
    elif ratio <= 1.4: return 2
    else: return 0

def score_pb(pb: float, roe: float) -> int:
    """
    Sub-factor 2C: Price to Book Ratio (+6 pts)
    Includes bonus rule: If ROE > 25% AND PB < 5, bonus +1 (but max is 6, so effectively 6)
    """
    if pb <= 1.5: return 6
    elif pb <= 3.0: return 5
    elif pb <= 5.0: return 4
    elif pb <= 8.0: return 2
    else: return 0

def calculate_pillar2(info: Dict, user_overrides: Dict = None) -> Dict:
    """Calculate Valuation score (max 20)."""
    user_overrides = user_overrides or {}

    sector = info.get("_sector", "General")
    sector_pe = get_sector_pe(sector)

    try:
        pe = float(info.get("trailingPE", 0) or info.get("forwardPE", 0) or 0)
        if pe < 0 or pe > 500:  # Sanity check
            pe = 0
    except (ValueError, TypeError):
        pe = 0.0

    try:
        pb = float(info.get("priceToBook", 0) or 0)
        if pb < 0 or pb > 100:
            pb = 0
    except (ValueError, TypeError):
        pb = 0.0

    # PEG = PE / Earnings Growth %
    try:
        growth_pct = float(info.get("earningsGrowth", 0)) * 100
        if growth_pct <= 0:
            growth_pct = 10  # Conservative default if negative or zero
    except (ValueError, TypeError):
        growth_pct = 10.0

    peg = pe / growth_pct if growth_pct > 0 else 99

    # Apply overrides
    pe = user_overrides.get("pe", pe)
    pb = user_overrides.get("pb", pb)
    peg = user_overrides.get("peg", peg)
    sector_pe = user_overrides.get("sector_pe", sector_pe)

    # Bonus rule check
    try:
        roe = float(info.get("returnOnEquity", 0))
        if roe > 1: roe = roe / 100
    except (ValueError, TypeError):
        roe = 0.0
    bonus = 0
    if roe > 0.25 and pb < 5 and pb > 0:
        bonus = 1  # As per document

    peg_score = score_peg(peg)
    pe_score = score_pe_vs_sector(pe, sector_pe)
    pb_score = score_pb(pb, roe)

    total = peg_score + pe_score + pb_score + bonus
    total = min(20, total)  # Cap at 20

    return {
        "score": total,
        "max": 20,
        "pe": pe,
        "pb": pb,
        "peg": peg,
        "sector_pe": sector_pe,
        "details": {
            "PEG Ratio": {"value": f"{peg:.2f}", "points": peg_score, "max": 8},
            "PE vs Sector": {"value": f"{pe:.1f}x vs {sector_pe:.1f}x", "points": pe_score, "max": 6},
            "Price/Book": {"value": f"{pb:.2f}x", "points": pb_score, "max": 6},
            "Quality Bonus (ROE>25% & PB<5)": {"value": "Yes" if bonus else "No", "points": bonus, "max": 1},
        }
    }

# ==================== PILLAR 3: GROWTH RUNWAY (20 pts) ====================

def score_tam_penetration(tam_score: str) -> int:
    """Sub-factor 3A: Sector TAM and Penetration Level (+8 pts)"""
    mapping = {
        "Large TAM, Low Penetration": 8,
        "Large TAM, Medium Penetration": 6,
        "Medium TAM, Low Penetration": 5,
        "Medium TAM, Medium Penetration": 4,
        "Mature Market": 2,
        "Declining": 0,
    }
    return mapping.get(tam_score, 4)

def score_india_macro(macro_score: str) -> int:
    """Sub-factor 3B: India Macro Tailwind (+7 pts)"""
    mapping = {
        "Two+ Structural Tailwinds": 7,
        "One Strong Tailwind": 5,
        "Moderate Tailwind": 3,
        "Tracks GDP": 2,
        "Headwind": 0,
    }
    return mapping.get(macro_score, 2)

def score_export_opportunity(export_score: str) -> int:
    """Sub-factor 3C: Export / Global Opportunity (+5 pts)"""
    mapping = {
        "Active Exporter": 5,
        "Export Plans Underway": 3,
        "Domestic Only, Large India": 2,
        "No Global Opportunity": 0,
    }
    return mapping.get(export_score, 2)

def calculate_pillar3(info: Dict, user_overrides: Dict = None) -> Dict:
    """
    Calculate Growth Runway score (max 20).
    Defaults based on sector heuristics; user can override via UI.
    """
    user_overrides = user_overrides or {}
    sector = info.get("_sector", "General")

    # Default heuristic mapping based on sector
    sector_defaults = {
        "Defence": ("Large TAM, Low Penetration", "Two+ Structural Tailwinds", "Export Plans Underway"),
        "IT": ("Large TAM, Medium Penetration", "One Strong Tailwind", "Active Exporter"),
        "Pharma": ("Large TAM, Low Penetration", "One Strong Tailwind", "Active Exporter"),
        "Chemicals": ("Medium TAM, Low Penetration", "One Strong Tailwind", "Active Exporter"),
        "FMCG": ("Medium TAM, Medium Penetration", "Tracks GDP", "Domestic Only, Large India"),
        "Auto": ("Medium TAM, Medium Penetration", "Moderate Tailwind", "Export Plans Underway"),
        "Banking": ("Large TAM, Medium Penetration", "One Strong Tailwind", "Domestic Only, Large India"),
        "NBFC": ("Large TAM, Medium Penetration", "One Strong Tailwind", "Domestic Only, Large India"),
        "Infra/Capex": ("Large TAM, Low Penetration", "Two+ Structural Tailwinds", "Domestic Only, Large India"),
        "Retail": ("Medium TAM, Medium Penetration", "Moderate Tailwind", "Domestic Only, Large India"),
        "Real Estate": ("Large TAM, Low Penetration", "Moderate Tailwind", "Domestic Only, Large India"),
    }

    defaults = sector_defaults.get(sector, ("Medium TAM, Medium Penetration", "Tracks GDP", "Domestic Only, Large India"))

    tam = user_overrides.get("tam_penetration", defaults[0])
    macro = user_overrides.get("india_macro", defaults[1])
    export = user_overrides.get("export_opportunity", defaults[2])

    tam_score = score_tam_penetration(tam)
    macro_score = score_india_macro(macro)
    export_score = score_export_opportunity(export)

    total = tam_score + macro_score + export_score

    return {
        "score": min(20, total),
        "max": 20,
        "details": {
            "TAM & Penetration": {"value": tam, "points": tam_score, "max": 8},
            "India Macro Tailwind": {"value": macro, "points": macro_score, "max": 7},
            "Export Opportunity": {"value": export, "points": export_score, "max": 5},
        }
    }

# ==================== PILLAR 4: COMPETITIVE MOAT (15 pts) ====================

def score_moat_type(moat_type: str) -> int:
    """Sub-factor 4A: Moat Type & Strength (+8 pts)"""
    mapping = {
        "Regulatory/Licence": 8,
        "Brand Power": 7,
        "Switching Costs": 7,
        "Network Effects": 7,
        "Cost Advantage": 6,
        "Efficient Scale": 6,
        "Weak/No Moat": 1,
    }
    return mapping.get(moat_type, 1)

def score_market_share_trend(trend: str) -> int:
    """Sub-factor 4B: Market Share Trend (+4 pts)"""
    mapping = {
        "Gaining": 4,
        "Stable": 2,
        "Declining Slowly": 1,
        "Declining Significantly": 0,
    }
    return mapping.get(trend, 2)

def score_pricing_power(power: str) -> int:
    """Sub-factor 4C: Pricing Power Evidence (+3 pts)"""
    mapping = {
        "Above Inflation": 3,
        "With Inflation": 2,
        "Market Driven": 0,
    }
    return mapping.get(power, 2)

def calculate_pillar4(info: Dict, user_overrides: Dict = None) -> Dict:
    """
    Calculate Competitive Moat score (max 15).
    Defaults based on financial heuristics.
    """
    user_overrides = user_overrides or {}
    sector = info.get("_sector", "General")

    # Heuristic moat detection
    try:
        roe = float(info.get("returnOnEquity", 0))
        if roe > 1: roe = roe / 100
    except (ValueError, TypeError):
        roe = 0.0

    try:
        margins = float(info.get("profitMargins", 0))
        if margins > 1: margins = margins / 100
    except (ValueError, TypeError):
        margins = 0.0

    # Default moat type based on sector and ROE
    if sector in ["Defence", "Railways", "Stock Exchanges"] or "regulated" in info.get("industry", "").lower():
        default_moat = "Regulatory/Licence"
    elif sector in ["FMCG", "Pharma", "Consumer Durables"] and roe > 0.20:
        default_moat = "Brand Power"
    elif sector in ["IT", "Banking", "NBFC"] and roe > 0.15:
        default_moat = "Switching Costs"
    elif sector in ["E-commerce", "Marketplaces", "Stock Exchanges"]:
        default_moat = "Network Effects"
    elif roe > 0.20 and margins > 0.15:
        default_moat = "Cost Advantage"
    else:
        default_moat = "Weak/No Moat"

    # Market share trend - default stable unless high growth suggests gaining
    try:
        revenue_growth = float(info.get("revenueGrowth", 0))
    except (ValueError, TypeError):
        revenue_growth = 0.0
    default_trend = "Gaining" if revenue_growth > 0.20 else "Stable" if revenue_growth > 0.05 else "Declining Slowly"

    # Pricing power from margin trend (assume stable if unknown)
    default_pricing = "With Inflation"
    if margins > 0.20:
        default_pricing = "Above Inflation"

    moat = user_overrides.get("moat_type", default_moat)
    trend = user_overrides.get("market_share_trend", default_trend)
    pricing = user_overrides.get("pricing_power", default_pricing)

    moat_score = score_moat_type(moat)
    trend_score = score_market_share_trend(trend)
    pricing_score = score_pricing_power(pricing)

    total = moat_score + trend_score + pricing_score

    return {
        "score": min(15, total),
        "max": 15,
        "details": {
            "Moat Type": {"value": moat, "points": moat_score, "max": 8},
            "Market Share Trend": {"value": trend, "points": trend_score, "max": 4},
            "Pricing Power": {"value": pricing, "points": pricing_score, "max": 3},
        }
    }

# ==================== PILLAR 5: MANAGEMENT QUALITY (10 pts) ====================

def score_promoter(holding: float, pledge: float, trend: str) -> int:
    """Sub-factor 5A: Promoter Holding & Pledge (+4 pts)"""
    if holding >= 0.50 and pledge <= 0 and trend == "Increasing":
        return 4
    elif holding >= 0.40 and pledge <= 0.05:
        return 3
    elif holding >= 0.25 and pledge <= 0:
        return 2
    elif pledge > 0.20 or (trend == "Declining" and holding < 0.40):
        return 0
    else:
        return 2  # Moderate case

def score_capital_allocation(roce: float, dividend_growth: bool, bad_acquisitions: bool) -> int:
    """Sub-factor 5B: Capital Allocation Track Record (+3 pts)"""
    if bad_acquisitions:
        return 0
    if roce > 0.20 and dividend_growth:
        return 3
    elif roce > 0.15:
        return 2
    else:
        return 1

def score_governance(audit_clean: bool, rpt_low: bool, board_independent: bool) -> int:
    """Sub-factor 5C: Governance & Transparency (+3 pts)"""
    if audit_clean and rpt_low and board_independent:
        return 3
    elif audit_clean:
        return 2
    else:
        return 0

def calculate_pillar5(info: Dict, user_overrides: Dict = None) -> Dict:
    """Calculate Management Quality score (max 10)."""
    user_overrides = user_overrides or {}

    # Extract from info if available
    try:
        promoter_holding = float(info.get("heldPercentInsiders", 0))
        if promoter_holding > 1:
            promoter_holding = promoter_holding / 100
    except (ValueError, TypeError):
        promoter_holding = 0.0

    # yfinance doesn't have pledge data directly - use defaults
    pledge = 0.0  # Assume clean unless known otherwise
    trend = "Stable"

    # ROCE for capital allocation
    try:
        roce = float(info.get("returnOnCapitalEmployed", 0))
        if roce > 1: roce = roce / 100
    except (ValueError, TypeError):
        roce = 0.0

    # Dividend info
    try:
        dividend_yield = float(info.get("dividendYield", 0) or 0)
        if dividend_yield > 1: dividend_yield = dividend_yield / 100
    except (ValueError, TypeError):
        dividend_yield = 0.0

    # Defaults
    default_audit = True
    default_rpt = True
    default_board = True

    # Apply overrides
    promoter_holding = user_overrides.get("promoter_holding", promoter_holding)
    pledge = user_overrides.get("promoter_pledge", pledge)
    trend = user_overrides.get("promoter_trend", trend)
    roce = user_overrides.get("roce", roce)
    bad_acq = user_overrides.get("bad_acquisitions", False)
    audit_clean = user_overrides.get("audit_clean", default_audit)
    rpt_low = user_overrides.get("rpt_low", default_rpt)
    board_ind = user_overrides.get("board_independent", default_board)

    p1 = score_promoter(promoter_holding, pledge, trend)
    p2 = score_capital_allocation(roce, dividend_yield > 0, bad_acq)
    p3 = score_governance(audit_clean, rpt_low, board_ind)

    total = p1 + p2 + p3

    return {
        "score": min(10, total),
        "max": 10,
        "promoter_holding": promoter_holding,
        "details": {
            "Promoter Holding & Pledge": {"value": f"{promoter_holding:.1%}, Pledge: {pledge:.1%}", "points": p1, "max": 4},
            "Capital Allocation": {"value": f"ROCE: {roce:.1%}", "points": p2, "max": 3},
            "Governance": {"value": "Clean" if audit_clean else "Concerns", "points": p3, "max": 3},
        }
    }

# ==================== PILLAR 6: ENTRY PRICE SAFETY (5 pts) ====================

def score_52w_position(pct_below: float) -> int:
    """Sub-factor 6A: % Below 52-Week High (+3 pts)"""
    if pct_below > 0.25: return 3
    elif pct_below > 0.10: return 2
    elif pct_below > 0: return 1
    else: return 0

def score_200dma(cmp: float, dma200: float) -> int:
    """Sub-factor 6B: Price Above 200 DMA (+2 pts)"""
    if cmp > dma200: return 2
    else: return 0

def calculate_pillar6(info: Dict, price_history: pd.DataFrame, user_overrides: Dict = None) -> Dict:
    """Calculate Entry Price Safety score (max 5)."""
    user_overrides = user_overrides or {}

    try:
        high_52w = float(info.get("fiftyTwoWeekHigh", 0))
    except (ValueError, TypeError):
        high_52w = 0.0

    try:
        cmp = float(info.get("currentPrice", 0)) or float(info.get("previousClose", 0))
    except (ValueError, TypeError):
        cmp = 0.0

    try:
        dma200 = float(info.get("twoHundredDayAverage", 0))
    except (ValueError, TypeError):
        dma200 = 0.0

    # Calculate from price history if info missing
    if not price_history.empty:
        if high_52w <= 0:
            try:
                high_52w = price_history["High"].max()
            except Exception:
                pass
        if cmp <= 0:
            try:
                cmp = price_history["Close"].iloc[-1]
            except Exception:
                pass
        if dma200 <= 0:
            try:
                dma200 = price_history["Close"].rolling(200, min_periods=50).mean().iloc[-1]
            except Exception:
                pass

    pct_below = safe_divide(high_52w - cmp, high_52w, 0) if high_52w > 0 else 0

    # Apply overrides
    pct_below = user_overrides.get("pct_below_52w", pct_below)
    cmp = user_overrides.get("cmp", cmp)
    dma200 = user_overrides.get("dma200", dma200)

    s1 = score_52w_position(pct_below)
    s2 = score_200dma(cmp, dma200)

    total = s1 + s2

    return {
        "score": min(5, total),
        "max": 5,
        "cmp": cmp,
        "high_52w": high_52w,
        "dma200": dma200,
        "pct_below": pct_below,
        "details": {
            "% Below 52W High": {"value": f"{pct_below:.1%}", "points": s1, "max": 3},
            "Above 200 DMA": {"value": "Yes" if s2 else "No", "points": s2, "max": 2},
        }
    }

# ==================== RED FLAGS ====================

def check_red_flags(info: Dict, pillar_scores: Dict) -> List[str]:
    """
    Check automatic disqualifiers from the document.
    Returns list of red flag strings.
    """
    flags = []

    # Promoter pledge > 50% (we don't have this in yfinance, but check if override exists)
    pledge = info.get("_pledge_override", 0)
    if pledge > 0.50:
        flags.append("CRITICAL: Promoter pledge > 50%")

    # Debt/Equity > 4 (except financials)
    try:
        de = float(info.get("debtToEquity", 0))
    except (ValueError, TypeError):
        de = 0.0
    if de > 400 or (de > 4 and de < 100):  # Handle both percentage and ratio formats
        sector = info.get("_sector", "")
        if sector not in ["Banking", "Financial Services", "NBFC", "Insurance"]:
            flags.append(f"CRITICAL: Debt/Equity {de:.1f} > 4 (non-financial)")

    # PAT negative for 3 consecutive years - hard to detect without full history
    # Use earnings growth as proxy
    try:
        earnings_growth = float(info.get("earningsGrowth", 0))
    except (ValueError, TypeError):
        earnings_growth = 0.0
    if earnings_growth < -0.50:
        flags.append("WARNING: Earnings declining significantly (>50%)")

    # Related Party Transactions > 20% (not available in yfinance)
    rpt = info.get("_rpt_override", 0)
    if rpt > 0.20:
        flags.append("CRITICAL: RPT > 20% of revenue")

    # Score-based red flags
    total_score = sum(p.get("score", 0) for p in pillar_scores.values())
    if total_score < 55:
        flags.append(f"Low total score: {total_score}/100 (AVOID territory)")

    # Pillar 1 drop check
    p1_score = pillar_scores.get("pillar1", {}).get("score", 30)
    if p1_score < 15:
        flags.append("WARNING: Business Quality score critically low (<15/30)")

    return flags

# ==================== MASTER SCORING FUNCTION ====================

def calculate_full_score(ticker: str, user_overrides: Dict = None) -> Dict:
    """
    Complete 6-pillar scoring for a stock.
    Returns comprehensive scorecard with all details.
    """
    user_overrides = user_overrides or {}

    ticker = ensure_ns_suffix(ticker)

    # Fetch data
    info = fetch_stock_info(ticker)
    income, balance, cashflow = fetch_financial_statements(ticker)

    # Get price history for technical calculations
    try:
        history = fetch_price_data(ticker, period="2y", interval="1d")
    except Exception:
        history = pd.DataFrame()

    # Calculate each pillar
    p1 = calculate_pillar1(info, income, balance, user_overrides.get("pillar1"))
    p2 = calculate_pillar2(info, user_overrides.get("pillar2"))
    p3 = calculate_pillar3(info, user_overrides.get("pillar3"))
    p4 = calculate_pillar4(info, user_overrides.get("pillar4"))
    p5 = calculate_pillar5(info, user_overrides.get("pillar5"))
    p6 = calculate_pillar6(info, history, user_overrides.get("pillar6"))

    total = p1["score"] + p2["score"] + p3["score"] + p4["score"] + p5["score"] + p6["score"]
    signal = get_signal_from_score(total)
    position_size = get_position_size_recommendation(signal)

    # Check red flags
    pillars = {"pillar1": p1, "pillar2": p2, "pillar3": p3, "pillar4": p4, "pillar5": p5, "pillar6": p6}
    red_flags = check_red_flags(info, pillars)

    return {
        "ticker": ticker,
        "name": info.get("longName", ticker),
        "sector": info.get("_sector", "General"),
        "total_score": total,
        "max_score": 100,
        "signal": signal,
        "position_size": position_size,
        "red_flags": red_flags,
        "pillars": pillars,
        "info": info,
        "history": history,
    }
