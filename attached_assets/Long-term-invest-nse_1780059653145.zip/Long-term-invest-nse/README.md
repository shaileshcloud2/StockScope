# NSE Analytics & 6-Pillar Investment Scoring Dashboard

A comprehensive, locally-run web application for analyzing NSE indices (Nifty 50, Nifty Midcap 150) and scoring individual stocks using a rigorous 6-pillar long-term investment framework.

## Features

### Index Analytics Dashboard
- **Normalized Returns Comparison**: Overlay Nifty 50 vs Nifty Midcap 150 on a single timeline
- **Risk/Reward Metrics**: Rolling Beta, CAGR, Maximum Drawdown, Sharpe Ratio (6% risk-free rate)
- **Ratio Analysis**: Midcap/Nifty ratio to identify market cycle rotations
- **Moving Averages**: SMA 50 and SMA 200 overlays
- **Date Range Controls**: Custom start/end date selection
- **Data Export**: Download CSV files for all datasets

### 6-Pillar Stock Scoring Engine
Based on the attached investment philosophy document:
1. **Business Quality** (30 pts): Revenue/PAT CAGR, ROE, ROCE, Debt/Equity
2. **Valuation** (20 pts): PEG, PE vs Sector, Price/Book
3. **Growth Runway** (20 pts): TAM/Penetration, India Macro, Export Opportunity
4. **Competitive Moat** (15 pts): Moat Type, Market Share, Pricing Power
5. **Management Quality** (10 pts): Promoter Holding, Capital Allocation, Governance
6. **Entry Price Safety** (5 pts): % Below 52W High, 200 DMA

### Portfolio Manager
- Add positions with shares and average cost
- Automatic re-scoring and rebalancing recommendations
- Exit rule triggers (score drops, red flags, etc.)
- Signal distribution visualization

## Tech Stack
- **Backend**: Python 3.10+, Streamlit
- **Data**: yfinance (Yahoo Finance API)
- **Processing**: Pandas, NumPy
- **Charts**: Plotly (interactive)
- **Cache**: SQLite local database

## Installation

### Step 1: Create a virtual environment (recommended)
```bash
python -m venv venv

# On Windows
venv\Scripts\activate

# On macOS/Linux
source venv/bin/activate
```

### Step 2: Install dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run the application
```bash
streamlit run app.py
```

The app will open in your default browser at `http://localhost:8501`.

## Project Structure
```
financial_app/
├── app.py                # Main Streamlit application
├── utils.py              # Constants, sector benchmarks, helper functions
├── data_fetcher.py       # yfinance integration with SQLite caching
├── analytics.py          # Financial metrics calculations
├── scoring_engine.py     # 6-pillar scoring logic
├── portfolio_manager.py  # Portfolio construction and rebalancing
├── visualizations.py     # Plotly chart generation
├── requirements.txt    # Python dependencies
└── data_cache/           # Auto-created SQLite cache directory
```

## Usage Guide

### Index Analytics
1. Select time period (1Y, 3Y, 5Y, Max)
2. Optionally adjust date range
3. Click "Fetch / Refresh Data" to load latest prices
4. View normalized returns, ratio charts, drawdowns, and SMA overlays
5. Download CSV files for further analysis

### Stock Screener
1. Enter an NSE ticker (e.g., `RELIANCE`, `TCS`, `HDFCBANK`)
2. Click "Analyze"
3. Review the 6-pillar score breakdown
4. Expand "Override Qualitative Scores" to manually adjust TAM, Moat, Management factors
5. Add to portfolio if desired

### Portfolio Manager
1. View all holdings and their current scores
2. Review automatic rebalancing recommendations
3. Check exit triggers and red flags
4. Remove positions that trigger exit rules

## Important Notes

### Data Sources & Limitations
- **Price Data**: Fetched from Yahoo Finance via `yfinance`
- **Index Tickers**: `^NSEI` (Nifty 50), `^NSEMDCP150` (Nifty Midcap 150)
  - If `^NSEMDCP150` is unavailable, edit `utils.py` to use an ETF proxy like `MIDCAPETF.NS`
- **Fundamentals**: yfinance provides basic financials. Qualitative pillars (Moat, TAM, Macro) use sector-based heuristics by default
- **Override Capability**: Always review and override qualitative scores for accurate analysis

### Cache
- All data is cached locally in SQLite (`data_cache/financial_data.db`)
- Cache auto-refreshes after 24 hours
- Use the "Data & Cache" page to monitor or clear cache

### Scoring Framework
- Scores are computed from publicly available data
- This is an analytical framework for personal use, NOT SEBI-registered investment advice
- Always verify data from company filings, Screener.in, and BSE/NSE before investing

## Troubleshooting

### yfinance rate limits
If you encounter rate limiting:
- Wait a few minutes and retry
- Use cached data (it persists for 24 hours)
- Clear cache from the Data & Cache page if data seems stale

### Missing index data
If `^NSEMDCP150` returns no data:
- Check `utils.py` and replace with a valid ETF ticker
- Common alternatives: `MIDCAPETF.NS`, `ICICIMCAP.NS`

### Network issues
- Ensure stable internet connection
- The app will attempt to use cached data if network fails
- Check firewall/proxy settings if behind corporate network

## Disclaimer
This scoring system is an analytical framework for personal use only. Scores are computed from publicly available data. This document is not SEBI-registered investment advice. Past performance of individual stocks does not guarantee future returns. Long-term equity investing involves risk of principal loss. Always verify data from company filings, Screener.in and BSE/NSE before making investment decisions. Consider consulting a SEBI-registered investment advisor for personalised advice.
