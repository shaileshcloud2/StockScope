"""
Main Application Entry Point.
Run with: streamlit run app.py

Provides:
- Index Analytics Dashboard (Nifty 50 vs Midcap 150)
- Stock Screener with 6-Pillar Scoring
- Portfolio Management with Rebalancing
"""

import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import plotly.graph_objects as go
from io import StringIO
import sqlite3
import re

# Page configuration
st.set_page_config(
    page_title="NSE Analytics & Scoring Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Import modules
from utils import (
    NIFTY_50_TICKER, NIFTY_MIDCAP_150_TICKER, TIMEFRAMES, RISK_FREE_RATE,
    format_percent, format_number, ensure_ns_suffix, remove_ns_suffix,
    get_signal_from_score, get_position_size_recommendation
)
from data_fetcher import fetch_price_data, fetch_stock_info, DB_PATH
from analytics import (
    calculate_normalized_returns, calculate_performance_metrics,
    calculate_index_comparison, calculate_sma, filter_by_date,
    calculate_max_drawdown, calculate_daily_returns
)
from scoring_engine import calculate_full_score
from portfolio_manager import PortfolioManager
from visualizations import (
    plot_normalized_comparison, plot_ratio, plot_rolling_beta,
    plot_drawdown, plot_price_with_sma, plot_score_breakdown,
    plot_portfolio_allocation
)
from stock_universe import NSE_STOCKS

# ==================== CSS STYLING ====================

st.markdown("""
<style>
    .main-header { font-size: 2.5rem; font-weight: bold; color: #1f2937; }
    .score-strong-buy { color: #27ae60; font-weight: bold; font-size: 1.2rem; }
    .score-buy { color: #2ecc71; font-weight: bold; font-size: 1.2rem; }
    .score-watchlist { color: #f39c12; font-weight: bold; font-size: 1.2rem; }
    .score-avoid { color: #e74c3c; font-weight: bold; font-size: 1.2rem; }
    .metric-card { background-color: #f8f9fa; border-radius: 10px; padding: 15px; border-left: 4px solid #3498db; }
    .red-flag { background-color: #fee2e2; color: #991b1b; padding: 10px; border-radius: 5px; margin: 5px 0; }
    .exit-trigger { background-color: #fecaca; color: #7f1d1d; padding: 10px; border-radius: 5px; margin: 5px 0; font-weight: bold; }
    .recommendation { background-color: #d1fae5; color: #065f46; padding: 10px; border-radius: 5px; margin: 5px 0; }
</style>
""", unsafe_allow_html=True)

# ==================== SIDEBAR ====================

st.sidebar.title("📊 Navigation")
page = st.sidebar.radio(
    "Select Dashboard",
    ["Index Analytics", "Stock Screener", "Portfolio Manager", "Data & Cache"]
)

st.sidebar.markdown("---")
st.sidebar.info("""
**Data Sources**
- Prices: Yahoo Finance (yfinance)
- Fundamentals: Screener.in heuristic + yfinance
- Risk-free rate: 6% (India)

**Note**: Qualitative scores (Moat, TAM, Macro) use sector-based defaults. 
Override in Stock Screener for accuracy.
""")


# ==================== STOCK LOOKUP DATA (shared across pages) ====================

# Build searchable stock mappings from NSE_STOCKS
_DISPLAY_TO_SYMBOL = {}
_SYMBOL_TO_DISPLAY = {}
for stock_ticker, stock_name in NSE_STOCKS:
    sym = remove_ns_suffix(stock_ticker)
    disp = f"{sym} — {stock_name}"
    _DISPLAY_TO_SYMBOL[disp] = sym
    _SYMBOL_TO_DISPLAY[sym] = disp

_ALL_DISPLAYS = list(_DISPLAY_TO_SYMBOL.keys())


def filter_stocks(query, max_results=15):
    """Filter stocks by symbol or company name. Returns list of (priority, display, symbol)."""
    if not query:
        return []
    query = query.upper().strip()
    results = []
    seen = set()

    for disp, sym in _DISPLAY_TO_SYMBOL.items():
        if sym in seen:
            continue
        name_upper = disp.split(" — ")[1].upper() if " — " in disp else ""

        if sym == query:
            results.append((0, disp, sym))  # Exact symbol match
            seen.add(sym)
        elif sym.startswith(query):
            results.append((1, disp, sym))
            seen.add(sym)
        elif query in name_upper:
            results.append((2, disp, sym))
            seen.add(sym)
        elif query in sym:
            results.append((3, disp, sym))
            seen.add(sym)

    results.sort(key=lambda x: x[0])
    return results[:max_results]


def period_to_yf_period(period_label):
    """Convert human-readable period to yfinance period string."""
    mapping = {
        "1 Year": "1y",
        "2 Years": "2y",
        "3 Years": "3y",
        "4 Years": "4y",
        "5 Years": "5y",
        "Max": "max",
    }
    return mapping.get(period_label, "5y")


def period_to_timedelta(period_label, custom_years=5):
    """Convert period label to timedelta for date calculation."""
    if period_label == "Max":
        return timedelta(days=20*365)
    elif period_label == "Custom":
        return timedelta(days=custom_years*365)
    else:
        match = re.match(r'(\d+)', period_label)
        if match:
            years = int(match.group(1))
            return timedelta(days=years*365)
    return timedelta(days=5*365)


# ==================== INDEX ANALYTICS PAGE ====================

if page == "Index Analytics":
    st.markdown('<p class="main-header">Nifty 50 vs Nifty Midcap 150 Analytics</p>', unsafe_allow_html=True)

    # --- Period Selection ---
    col1, col2, col3 = st.columns(3)

    with col1:
        period_options = ["1 Year", "2 Years", "3 Years", "4 Years", "5 Years", "Max", "Custom"]

        # Initialize session state for period tracking
        if "last_period" not in st.session_state:
            st.session_state.last_period = "5 Years"
            st.session_state.last_custom_years = 5

        selected_period = st.selectbox(
            "Time Period",
            period_options,
            index=4,  # Default to 5 Years
            key="index_period"
        )

    # Handle custom period
    custom_years = 5
    if selected_period == "Custom":
        custom_col1, custom_col2 = st.columns(2)
        with custom_col1:
            custom_years = st.number_input("Enter Years", min_value=1, max_value=20, value=5, step=1, key="custom_years")
        with custom_col2:
            st.markdown("<br>", unsafe_allow_html=True)
            st.caption("Custom period: fetch data for specified years")

    # Compute dates based on selected period
    yf_period = period_to_yf_period(selected_period) if selected_period != "Custom" else f"{custom_years}y"
    period_delta = period_to_timedelta(selected_period, custom_years)

    computed_end = datetime.now().date()
    computed_start = (datetime.now() - period_delta).date()

    # Check if period changed and sync dates
    period_changed = (
        st.session_state.last_period != selected_period
        or (selected_period == "Custom" and st.session_state.last_custom_years != custom_years)
    )

    # Store computed dates in session state for persistence across reruns
    if "idx_start_date" not in st.session_state or period_changed:
        st.session_state.idx_start_date = computed_start
    if "idx_end_date" not in st.session_state or period_changed:
        st.session_state.idx_end_date = computed_end

    if period_changed:
        st.session_state.last_period = selected_period
        st.session_state.last_custom_years = custom_years
        st.rerun()

    with col2:
        start_date = st.date_input(
            "Start Date",
            value=st.session_state.idx_start_date,
            key="idx_start_date_widget"
        )

    with col3:
        end_date = st.date_input(
            "End Date",
            value=st.session_state.idx_end_date,
            key="idx_end_date_widget"
        )

    # Sync widget values back to session state
    st.session_state.idx_start_date = start_date
    st.session_state.idx_end_date = end_date

    # --- Fetch Data (auto-fetch on load) ---
    with st.spinner(f"Fetching index data for {selected_period}..."):
        try:
            nifty = fetch_price_data(NIFTY_50_TICKER, period=yf_period, force_refresh=True)
            midcap = fetch_price_data(NIFTY_MIDCAP_150_TICKER, period=yf_period, force_refresh=True)
        except Exception as e:
            st.error(f"Error fetching fresh data: {e}")
            try:
                nifty = fetch_price_data(NIFTY_50_TICKER, period=yf_period)
                midcap = fetch_price_data(NIFTY_MIDCAP_150_TICKER, period=yf_period)
            except Exception as e2:
                st.error(f"Cache also unavailable: {e2}")
                nifty = pd.DataFrame()
                midcap = pd.DataFrame()

    if nifty.empty or midcap.empty:
        st.warning("No data available. Please check your internet connection or try a different period.")
        st.info("Tip: If ^NSEMDCP150 is unavailable in yfinance, you may need to use an ETF proxy like MIDCAPETF.NS. Edit utils.py to change NIFTY_MIDCAP_150_TICKER.")
    else:
        # Show data range info
        nifty_start = nifty.index[0].strftime('%Y-%m-%d') if hasattr(nifty.index[0], 'strftime') else str(nifty.index[0])[:10]
        nifty_end = nifty.index[-1].strftime('%Y-%m-%d') if hasattr(nifty.index[-1], 'strftime') else str(nifty.index[-1])[:10]

        # Filter by date
        nifty_filtered = filter_by_date(nifty, start_date, end_date)
        midcap_filtered = filter_by_date(midcap, start_date, end_date)

        st.caption(f"Data range: {nifty_start} to {nifty_end} | Filtered: {start_date} to {end_date} | Points: {len(nifty_filtered)}")

        if nifty_filtered.empty or midcap_filtered.empty:
            st.warning("No data in selected date range. Adjust dates to match available data.")
        else:
            # Ensure Close column exists (yfinance uses capitalized, cache may differ)
            close_col = "Close" if "Close" in nifty_filtered.columns else "close"
            mid_close_col = "Close" if "Close" in midcap_filtered.columns else "close"

            # Calculate comparison metrics
            comparison = calculate_index_comparison(
                nifty_filtered[close_col],
                midcap_filtered[mid_close_col]
            )

            # Key Metrics Cards
            st.subheader("Performance Metrics")
            m_col1, m_col2, m_col3, m_col4, m_col5 = st.columns(5)

            with m_col1:
                st.metric("Nifty 50 CAGR", format_percent(comparison["nifty_metrics"]["CAGR"]))
            with m_col2:
                st.metric("Midcap 150 CAGR", format_percent(comparison["midcap_metrics"]["CAGR"]))
            with m_col3:
                st.metric("Nifty Sharpe", f"{comparison['nifty_metrics']['Sharpe Ratio']:.2f}")
            with m_col4:
                st.metric("Midcap Sharpe", f"{comparison['midcap_metrics']['Sharpe Ratio']:.2f}")
            with m_col5:
                current_ratio = comparison["ratio"].iloc[-1] if not comparison["ratio"].empty else 0
                st.metric("Current Ratio", f"{current_ratio:.2f}")

            # Charts
            st.subheader("Normalized Returns Comparison")
            fig1 = plot_normalized_comparison(comparison)
            st.plotly_chart(fig1, use_container_width=True)

            c1, c2 = st.columns(2)
            with c1:
                st.subheader("Midcap / Nifty Ratio")
                fig2 = plot_ratio(comparison["ratio"])
                st.plotly_chart(fig2, use_container_width=True)
            with c2:
                st.subheader("Rolling Beta (252-day)")
                fig3 = plot_rolling_beta(comparison["rolling_beta"])
                st.plotly_chart(fig3, use_container_width=True)

            # Drawdowns
            st.subheader("Drawdown Analysis")
            dd_col1, dd_col2 = st.columns(2)
            with dd_col1:
                fig_dd1 = plot_drawdown(nifty_filtered[close_col], "Nifty 50 Drawdown")
                st.plotly_chart(fig_dd1, use_container_width=True)
            with dd_col2:
                fig_dd2 = plot_drawdown(midcap_filtered[mid_close_col], "Midcap 150 Drawdown")
                st.plotly_chart(fig_dd2, use_container_width=True)

            # SMA Overlay
            st.subheader("Moving Average Overlay")
            show_sma = st.checkbox("Show SMA 50 & 200", value=True)
            if show_sma:
                sma_col1, sma_col2 = st.columns(2)
                with sma_col1:
                    sma50_n = calculate_sma(nifty_filtered[close_col], 50)
                    sma200_n = calculate_sma(nifty_filtered[close_col], 200)
                    fig_sma1 = plot_price_with_sma(nifty_filtered[close_col], sma50_n, sma200_n, "Nifty 50")
                    st.plotly_chart(fig_sma1, use_container_width=True)
                with sma_col2:
                    sma50_m = calculate_sma(midcap_filtered[mid_close_col], 50)
                    sma200_m = calculate_sma(midcap_filtered[mid_close_col], 200)
                    fig_sma2 = plot_price_with_sma(midcap_filtered[mid_close_col], sma50_m, sma200_m, "Midcap 150")
                    st.plotly_chart(fig_sma2, use_container_width=True)

            # Detailed Metrics Table
            st.subheader("Detailed Metrics")
            metrics_df = pd.DataFrame({
                "Metric": ["CAGR", "Annualized Volatility", "Sharpe Ratio", "Max Drawdown", "Calmar Ratio", "Total Return"],
                "Nifty 50": [
                    format_percent(comparison["nifty_metrics"]["CAGR"]),
                    format_percent(comparison["nifty_metrics"]["Volatility (Ann.)"]),
                    f"{comparison['nifty_metrics']['Sharpe Ratio']:.2f}",
                    format_percent(comparison["nifty_metrics"]["Max Drawdown"]),
                    f"{comparison['nifty_metrics']['Calmar Ratio']:.2f}",
                    format_percent(comparison["nifty_metrics"]["Total Return"]),
                ],
                "Midcap 150": [
                    format_percent(comparison["midcap_metrics"]["CAGR"]),
                    format_percent(comparison["midcap_metrics"]["Volatility (Ann.)"]),
                    f"{comparison['midcap_metrics']['Sharpe Ratio']:.2f}",
                    format_percent(comparison["midcap_metrics"]["Max Drawdown"]),
                    f"{comparison['midcap_metrics']['Calmar Ratio']:.2f}",
                    format_percent(comparison["midcap_metrics"]["Total Return"]),
                ]
            })
            st.dataframe(metrics_df, use_container_width=True, hide_index=True)

            # Download buttons
            st.subheader("Export Data")
            d_col1, d_col2, d_col3 = st.columns(3)
            with d_col1:
                csv_nifty = nifty_filtered.to_csv()
                st.download_button("Download Nifty 50 CSV", csv_nifty, "nifty50_data.csv", "text/csv")
            with d_col2:
                csv_midcap = midcap_filtered.to_csv()
                st.download_button("Download Midcap 150 CSV", csv_midcap, "midcap150_data.csv", "text/csv")
            with d_col3:
                combined = pd.DataFrame({
                    "Nifty50_Close": nifty_filtered["Close"],
                    "Nifty50_Normalized": comparison["nifty_normalized"],
                    "Midcap150_Close": midcap_filtered["Close"],
                    "Midcap150_Normalized": comparison["midcap_normalized"],
                    "Ratio": comparison["ratio"],
                })
                csv_combined = combined.to_csv()
                st.download_button("Download Combined CSV", csv_combined, "combined_analysis.csv", "text/csv")


# ==================== STOCK SCREENER PAGE ====================

elif page == "Stock Screener":
    st.markdown('<p class="main-header">6-Pillar Investment Scoring Engine</p>', unsafe_allow_html=True)

    st.info("""
    Search and select an NSE stock to calculate the full 6-pillar score.
    Quantitative data is fetched automatically. Qualitative factors use sector defaults — expand 
    'Override Qualitative Scores' to adjust for accuracy.
    """)

    # --- Autocomplete Search ---
    search_col1, search_col2 = st.columns([3, 1])

    with search_col1:
        search_query = st.text_input(
            "Search Stock (Symbol or Name)",
            placeholder="Type to search e.g. RELIANCE or Reliance Industries...",
            key="stock_search"
        )

    # Filter suggestions based on search query
    selected_stock = None
    if search_query:
        query_upper = search_query.upper().strip()
        filtered = filter_stocks(query_upper, max_results=15)

        if filtered:
            st.caption(f"Found {len(filtered)} matching stock(s). Select one to analyze:")
            suggestion_options = [f[1] for f in filtered]

            selected_display = st.selectbox(
                "Select Stock",
                ["-- Select a stock --"] + suggestion_options,
                key="stock_select"
            )

            if selected_display != "-- Select a stock --":
                selected_stock = _DISPLAY_TO_SYMBOL[selected_display]
        else:
            st.warning(f"No stocks found matching '{query_upper}'. You can still try analyzing it directly.")
            # Allow direct symbol entry
            selected_stock = query_upper
    else:
        # Show all stocks in dropdown when no search query
        selected_display = st.selectbox(
            "Or Select from Full List",
            ["-- Select a stock --"] + _ALL_DISPLAYS,
            key="stock_full_select"
        )
        if selected_display != "-- Select a stock --":
            selected_stock = _DISPLAY_TO_SYMBOL[selected_display]

    with search_col2:
        st.markdown("<br>", unsafe_allow_html=True)
        analyze_btn = st.button("Analyze", type="primary", use_container_width=True)

    # Determine the stock to analyze
    stock_to_analyze = None
    if selected_stock and analyze_btn:
        stock_to_analyze = selected_stock
    elif search_query and analyze_btn:
        stock_to_analyze = search_query.upper().strip()

    if stock_to_analyze and analyze_btn:
        ticker = ensure_ns_suffix(stock_to_analyze)

        with st.spinner(f"Fetching and analyzing {remove_ns_suffix(ticker)}..."):
            try:
                info = fetch_stock_info(ticker)
                sector = info.get("_sector", "General")

                st.caption(f"Detected Sector: **{sector}** | Using sector defaults for qualitative pillars")

                # User overrides section
                with st.expander("Override Qualitative Scores (Optional)"):
                    o_col1, o_col2, o_col3 = st.columns(3)

                    overrides = {}

                    with o_col1:
                        st.markdown("**Pillar 3: Growth Runway**")
                        tam = st.selectbox("TAM & Penetration",
                            ["Large TAM, Low Penetration", "Large TAM, Medium Penetration",
                             "Medium TAM, Low Penetration", "Medium TAM, Medium Penetration",
                             "Mature Market", "Declining"],
                            index=0, key="tam")
                        macro = st.selectbox("India Macro Tailwind",
                            ["Two+ Structural Tailwinds", "One Strong Tailwind", "Moderate Tailwind",
                             "Tracks GDP", "Headwind"],
                            index=0, key="macro")
                        export = st.selectbox("Export Opportunity",
                            ["Active Exporter", "Export Plans Underway", "Domestic Only, Large India", "No Global Opportunity"],
                            index=2, key="export")
                        overrides["pillar3"] = {
                            "tam_penetration": tam,
                            "india_macro": macro,
                            "export_opportunity": export
                        }

                    with o_col2:
                        st.markdown("**Pillar 4: Competitive Moat**")
                        moat = st.selectbox("Moat Type",
                            ["Regulatory/Licence", "Brand Power", "Switching Costs", "Network Effects",
                             "Cost Advantage", "Efficient Scale", "Weak/No Moat"],
                            index=1, key="moat")
                        mkt_trend = st.selectbox("Market Share Trend",
                            ["Gaining", "Stable", "Declining Slowly", "Declining Significantly"],
                            index=1, key="mkt_trend")
                        pricing = st.selectbox("Pricing Power",
                            ["Above Inflation", "With Inflation", "Market Driven"],
                            index=1, key="pricing")
                        overrides["pillar4"] = {
                            "moat_type": moat,
                            "market_share_trend": mkt_trend,
                            "pricing_power": pricing
                        }

                    with o_col3:
                        st.markdown("**Pillar 5: Management Quality**")
                        prom_hold = st.slider("Promoter Holding", 0.0, 1.0, 0.51, 0.01, key="prom_hold")
                        prom_pledge = st.slider("Promoter Pledge", 0.0, 1.0, 0.0, 0.01, key="prom_pledge")
                        audit = st.checkbox("Clean Audit", value=True, key="audit")
                        rpt = st.checkbox("Low RPT (<5%)", value=True, key="rpt")
                        board = st.checkbox("Independent Board", value=True, key="board")
                        overrides["pillar5"] = {
                            "promoter_holding": prom_hold,
                            "promoter_pledge": prom_pledge,
                            "audit_clean": audit,
                            "rpt_low": rpt,
                            "board_independent": board
                        }

                # Calculate score
                scorecard = calculate_full_score(ticker, user_overrides=overrides)

                # Display results
                st.divider()
                header_col1, header_col2, header_col3 = st.columns([2, 1, 1])

                with header_col1:
                    st.subheader(f"{scorecard['name']} ({remove_ns_suffix(ticker)})")
                    st.caption(f"Sector: {scorecard['sector']}")

                with header_col2:
                    signal_class = f"score-{scorecard['signal'].lower().replace(' ', '-')}"
                    st.markdown(f'<p class="{signal_class}">{scorecard["signal"]}</p>', unsafe_allow_html=True)

                with header_col3:
                    st.metric("Total Score", f"{scorecard['total_score']}/100")

                # Score breakdown chart
                fig_score = plot_score_breakdown(scorecard)
                st.plotly_chart(fig_score, use_container_width=True)

                # Pillar details
                st.subheader("Pillar Breakdown")
                for pillar_key, pillar_name in [
                    ("pillar1", "Pillar 1: Business Quality (30 pts)"),
                    ("pillar2", "Pillar 2: Valuation (20 pts)"),
                    ("pillar3", "Pillar 3: Growth Runway (20 pts)"),
                    ("pillar4", "Pillar 4: Competitive Moat (15 pts)"),
                    ("pillar5", "Pillar 5: Management Quality (10 pts)"),
                    ("pillar6", "Pillar 6: Entry Price Safety (5 pts)"),
                ]:
                    with st.expander(f"{pillar_name} — **{scorecard['pillars'][pillar_key]['score']}/{scorecard['pillars'][pillar_key]['max']} pts**"):
                        details = scorecard['pillars'][pillar_key]['details']
                        detail_df = pd.DataFrame([
                            {"Factor": k, "Value": v["value"], "Points": v["points"], "Max": v["max"]}
                            for k, v in details.items()
                        ])
                        st.dataframe(detail_df, use_container_width=True, hide_index=True)

                # Red flags
                if scorecard["red_flags"]:
                    st.subheader("Red Flags")
                    for flag in scorecard["red_flags"]:
                        st.markdown(f'<div class="red-flag">⚠️ {flag}</div>', unsafe_allow_html=True)
                else:
                    st.success("No red flags detected")

                # Action recommendation
                st.subheader("Investment Recommendation")
                st.markdown(f"""
                **Signal:** {scorecard['signal']}  
                **Suggested Allocation:** {scorecard['position_size']}  
                **Rationale:** Based on the 6-pillar framework for a 5-6 year horizon.
                """)

                # Add to portfolio
                st.divider()
                st.subheader("Portfolio Action")
                pf_col1, pf_col2, pf_col3 = st.columns(3)
                with pf_col1:
                    shares = st.number_input("Shares Held", min_value=0.0, value=0.0, step=1.0, key="pf_shares")
                with pf_col2:
                    avg_cost = st.number_input("Average Cost (₹)", min_value=0.0, value=0.0, step=0.1, key="pf_cost")
                with pf_col3:
                    if st.button("Add to Portfolio", use_container_width=True):
                        pm = PortfolioManager()
                        success = pm.add_position(ticker, shares, avg_cost,
                                                  notes=f"Score: {scorecard['total_score']}, Signal: {scorecard['signal']}")
                        if success:
                            st.success(f"Added {remove_ns_suffix(ticker)} to portfolio!")
                        else:
                            st.error("Failed to add to portfolio")

            except Exception as e:
                st.error(f"Analysis failed: {str(e)}")
                st.info("Common issues: Invalid ticker, network error, or yfinance rate limit. Try again in a moment.")


# ==================== PORTFOLIO MANAGER PAGE ====================

elif page == "Portfolio Manager":
    st.markdown('<p class="main-header">Long-Term Portfolio Dashboard</p>', unsafe_allow_html=True)

    pm = PortfolioManager()

    # Add manual position with autocomplete
    with st.expander("Add Position Manually"):
        ap_col1, ap_col2, ap_col3 = st.columns(3)

        with ap_col1:
            manual_search = st.text_input(
                "Search Ticker",
                placeholder="Type to search...",
                key="manual_search"
            )

            if manual_search:
                manual_filtered = filter_stocks(manual_search.upper().strip(), max_results=10)

                if manual_filtered:
                    manual_options = [f[1] for f in manual_filtered]
                    manual_selected = st.selectbox(
                        "Select",
                        ["-- Select --"] + manual_options,
                        key="manual_select"
                    )
                    if manual_selected != "-- Select --":
                        new_ticker = _DISPLAY_TO_SYMBOL[manual_selected]
                    else:
                        new_ticker = manual_search.upper().strip()
                else:
                    new_ticker = manual_search.upper().strip()
            else:
                new_ticker = ""

        with ap_col2:
            new_shares = st.number_input("Shares", min_value=0.0, step=1.0, key="manual_shares")
        with ap_col3:
            new_cost = st.number_input("Avg Cost (₹)", min_value=0.0, step=0.1, key="manual_cost")

        if st.button("Add Position"):
            if new_ticker:
                t = ensure_ns_suffix(new_ticker)
                success = pm.add_position(t, new_shares, new_cost)
                if success:
                    st.success(f"Added {remove_ns_suffix(t)}")
                    st.rerun()

    # Get portfolio and recommendations
    portfolio = pm.get_portfolio()

    if portfolio.empty:
        st.info("No positions in portfolio. Use the Stock Screener to analyze stocks and add them here.")
    else:
        st.subheader(f"Portfolio Holdings ({len(portfolio)} positions)")
        st.dataframe(portfolio[["ticker", "shares", "avg_cost", "added_date", "notes"]],
                     use_container_width=True, hide_index=True)

        st.divider()
        st.subheader("Rebalancing Analysis")

        with st.spinner("Analyzing all positions..."):
            recommendations = pm.get_rebalancing_recommendations()

        # Summary stats
        sig_counts = {}
        for r in recommendations:
            sig_counts[r["signal"]] = sig_counts.get(r["signal"], 0) + 1

        sig_col1, sig_col2, sig_col3, sig_col4 = st.columns(4)
        with sig_col1:
            st.metric("Strong Buy", sig_counts.get("STRONG BUY", 0))
        with sig_col2:
            st.metric("Buy", sig_counts.get("BUY", 0))
        with sig_col3:
            st.metric("Watchlist", sig_counts.get("WATCHLIST", 0))
        with sig_col4:
            st.metric("Avoid / Exit", sig_counts.get("AVOID", 0) + len([r for r in recommendations if r["action"] == "EXIT"]))

        # Allocation pie chart
        fig_alloc = plot_portfolio_allocation(recommendations)
        st.plotly_chart(fig_alloc, use_container_width=True)

        # Detailed recommendations
        st.subheader("Position-by-Position Recommendations")
        for rec in recommendations:
            with st.container():
                rec_col1, rec_col2, rec_col3 = st.columns([2, 2, 1])

                with rec_col1:
                    st.write(f"**{remove_ns_suffix(rec['ticker'])}**")
                    st.caption(f"Score: {rec['score']}/100 | Signal: {rec['signal']}")

                with rec_col2:
                    if rec["action"] == "EXIT":
                        st.markdown(f'<div class="exit-trigger">🔴 {rec["action"]}: {rec["reason"]}</div>', unsafe_allow_html=True)
                    elif rec["action"] in ["HOLD/ADD", "HOLD"]:
                        st.markdown(f'<div class="recommendation">🟢 {rec["action"]}: {rec["reason"]}</div>', unsafe_allow_html=True)
                    else:
                        st.warning(f"{rec['action']}: {rec['reason']}")

                with rec_col3:
                    if rec["action"] == "EXIT":
                        if st.button("Remove", key=f"rem_{rec['ticker']}"):
                            pm.remove_position(rec['ticker'])
                            st.rerun()

                if rec["red_flags"]:
                    for flag in rec["red_flags"]:
                        st.markdown(f'<div class="red-flag">⚠️ {flag}</div>', unsafe_allow_html=True)

                st.divider()


# ==================== DATA & CACHE PAGE ====================

elif page == "Data & Cache":
    st.markdown('<p class="main-header">Data Management</p>', unsafe_allow_html=True)

    st.subheader("Cache Status")
    st.info(f"Database location: `{DB_PATH}`")

    # Show cached tickers
    conn = sqlite3.connect(DB_PATH)
    try:
        price_tickers = pd.read_sql_query("SELECT DISTINCT ticker FROM price_data", conn)
    except:
        price_tickers = pd.DataFrame()
    try:
        fund_tickers = pd.read_sql_query("SELECT DISTINCT ticker FROM fundamentals", conn)
    except:
        fund_tickers = pd.DataFrame()
    conn.close()

    st.write("**Cached Price Data:**")
    if not price_tickers.empty:
        st.write(", ".join(price_tickers["ticker"].tolist()))
    else:
        st.write("None")

    st.write("**Cached Fundamentals:**")
    if not fund_tickers.empty:
        st.write(", ".join(fund_tickers["ticker"].tolist()))
    else:
        st.write("None")

    # Clear cache
    st.subheader("Cache Operations")
    if st.button("Clear All Cache", type="secondary"):
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM price_data")
        cursor.execute("DELETE FROM fundamentals")
        conn.commit()
        conn.close()
        st.success("Cache cleared!")
        st.rerun()
