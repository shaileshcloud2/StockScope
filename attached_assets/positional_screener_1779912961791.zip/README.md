# Positional Screener - NSE 500 (Yahoo Finance Edition)

Fully local stock screener for NSE 500. No API keys. No login. Runs on your laptop.

## Quick Start

```bash
pip install -r requirements.txt
python update_fundamentals.py   # monthly
python server.py                  # start app
```

Open http://localhost:3000

## What's New (v3.1)
- **Replaced REST API with yfinance library** - much more reliable, handles cookies/session automatically
- **Better error handling** - shows clear messages if Yahoo Finance is unreachable
- **Batch size reduced to 20** - prevents rate limiting
- **Progress updates during quote fetching** - see what's happening

## Security
- Binds to 127.0.0.1 (localhost only) by default
- No credentials or API keys needed
- CSP + security headers enabled

## Scoring (100 points)
| Dimension | Max | Source |
|-----------|-----|--------|
| Trend | 25 | 50/200 DMA, Golden Cross, HH/HL |
| Momentum | 20 | RSI, vs Nifty 500, Volume ratio |
| Fundamental | 25 | PE, PB, ROE, D/E, Promoter (CSV) |
| Sector Tailwind | 15 | Nifty sector index 1Y returns (YF) |
| Risk:Reward | 15 | Support distance, ATR-based SL |

## Files
- `server.py` - Flask backend + scan engine (uses yfinance)
- `update_fundamentals.py` - Monthly fundamentals updater (uses yfinance)
- `data/nse500_symbols.csv` - 500 symbols
- `data/fundamentals.csv` - Cached fundamentals
- `public/index.html` - Dark-mode SPA frontend
